import { useCallback } from 'react';
import { execute } from '@aboutyou/backbone/helpers/execute';
import {
  APISortOrder,
  createProductsSearchEndpointRequest,
} from '@aboutyou/backbone/endpoints/products/products';
import { useAsyncLoader } from './useAsyncLoader';
import { normalizeProduct } from './normalizeProduct';
import { AttributeKey } from '@aboutyou/backbone/types/AttributeOrAttributeValueFilter';

const SHOP_ID = 139;

export const useProductLoader = (
  selectedColors: string[],
  SelectedMaterials: string[],
  selectedFiltersOptions: Map<string, string[]>,
) => {
  const products = useAsyncLoader(
    useCallback(
      () =>
        execute(
          'http://0.0.0.0:9459/v1/',
          SHOP_ID,
          createProductsSearchEndpointRequest({
            where: {
              categoryId: 20290,
              attributes: [
                {
                  type: 'attributes' as 'attributes',
                  key: 'color' as AttributeKey,
                  values: selectedColors,
                },
                {
                  type: 'attributes' as 'attributes',
                  key: 'materialStyle' as AttributeKey,
                  values: SelectedMaterials,
                },
              ],
            },
            pagination: {
              page: 1,
              perPage: 50,
            },
            sort: {
              channel: 'etkp',
              direction: APISortOrder.Descending,
              score: 'category_scores',
            },
            with: {
              attributes: {
                withKey: ['brand', 'colorDetail'],
              },
              priceRange: true,
            },
          }),
        ).then(({ data }) => data.entities.map(normalizeProduct)),
      [selectedFiltersOptions],
    ),
  );

  return Array.isArray(products) ? products : [];
};
