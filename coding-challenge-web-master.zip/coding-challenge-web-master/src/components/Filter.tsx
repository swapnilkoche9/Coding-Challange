import React, { FC, useContext, useState } from 'react';
import Checkbox from './CheckBox';
import { constants } from '../modules/constants';
import styled from 'styled-components';
import { FilterOptions, Filter } from '../types/Filter';
import { SelectedFilterOptionsContext } from '../context/selectedFilterOptions';

interface FilterProps {
  filter: Filter;
  onChange?: (ev: React.ChangeEvent<HTMLInputElement>) => void;
  clearAllFilterOptions?: (filterName: string) => void;
}

const Filter: FC<FilterProps> = ({
  filter,
  onChange,
  clearAllFilterOptions,
}) => {
  const selectedFilterOptions = useContext(SelectedFilterOptionsContext);
  const filterOptionsCount = filter.values.length;
  const filterOptionsValues: FilterOptions[] =
    filterOptionsCount > 16 ? filter.values.slice(0, 16) : filter.values;
  const [filterOptions, setFilterOptions] = useState(filterOptionsValues);
  const [showMoreButtonVisibility, setShowMoreButtonVisibility] = useState(
    true,
  );

  const showMoreFilterOptions = () => {
    setFilterOptions(filter.values);
    setShowMoreButtonVisibility(false);
  };

  const showLessFilterOptions = () => {
    setFilterOptions(filterOptionsValues);
    setShowMoreButtonVisibility(true);
  };

  return (
    <FilterWrapper>
      <FilterHeader>
        <h3>{filter.name}</h3>
        <ClearAllButton onClick={() => clearAllFilterOptions(filter.name)}>
          <label>{constants.clear_all__button_label}</label>
        </ClearAllButton>
      </FilterHeader>

      <FilterValues>
        {filterOptions.map(filterValue => (
          <CheckboxWrapper key={filterValue.name}>
            <Checkbox
              key={filterValue.name}
              id={filterValue.id.toString()}
              checked={
                selectedFilterOptions.has(filter.name) &&
                selectedFilterOptions
                  .get(filter.name)
                  .includes(filterValue.id.toString())
              }
              name={filter.name}
              label={filterValue.name}
              onChange={onChange}
            />
          </CheckboxWrapper>
        ))}
      </FilterValues>
      {showMoreButtonVisibility && filterOptionsCount > 16 && (
        <MoreButton onClick={showMoreFilterOptions}>
          <label>{constants.show_more_materials_button_label}</label>
        </MoreButton>
      )}
      {!showMoreButtonVisibility && filterOptionsCount > 16 && (
        <LessButton onClick={showLessFilterOptions}>
          <label>{constants.show_less_materials_button_label}</label>
        </LessButton>
      )}
    </FilterWrapper>
  );
};

const FilterWrapper = styled.header`
  background:#ffffff;
  display: flex;
  padding:20px
  flex-direction: column;
`;

const FilterHeader = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
`;

const FilterValues = styled.div`
  display: flex;

  flex-wrap: wrap;
  flex-direction: row;
`;

const LessButton = styled.button`
  width: 100%;
  position: relative;
  background: linear-gradient(transparent 15%, rgb(255, 255, 255) 45%);
  border: 0;
  margin-top: 20px;
  outline: none;

  > label {
    font-size: initial;
    font-size: 14px;
    line-height: 1.28571;
    color: rgb(155, 155, 155);

    &:hover,
    &:focus,
    &:active {
       {
        color: black;
      }
    }
  }
`;

const MoreButton = styled(LessButton)`
  margin-top: -35px;
  padding-top: 45px;
  }
`;

const ClearAllButton = styled(LessButton)`
  width: 120px;
  margin-top: 4px;
  padding-top: unset;
  display: flex;
`;

const CheckboxWrapper = styled.div`
  margin-top: 4px;
  width: 50%;
`;

export default Filter;
