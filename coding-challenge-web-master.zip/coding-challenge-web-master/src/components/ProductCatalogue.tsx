import React, { FC, useState } from 'react';
import styled from 'styled-components';
import Checkbox from './CheckBox';
import Header from './Header';
import ProductStream from './ProductStream';
import FilterPanel from './FilterPanel';
import { Product } from '../types/Product';
import { useFilterLoader } from '../api/useFilterLoader';
import { useProductLoader } from '../api/useProductLoader';
import { SelectedFilterOptionsContext } from '../context/selectedFilterOptions';
import { Filter } from '../types/Filter';

const ProductCatalogue = () => {
  const [filterPanelVisibility, setFilterPanelVisibility] = useState<boolean>(
    false,
  );
  const [selectedFiltersOptions, setSelectedFiltersOptions] = useState(
    new Map<string, string[]>(),
  );
  const filters: Filter[] = useFilterLoader();
  const selectedColors = selectedFiltersOptions.has('Suchfarbe')
    ? selectedFiltersOptions.get('Suchfarbe')
    : [];
  const SelectedMaterials = selectedFiltersOptions.has('Material')
    ? selectedFiltersOptions.get('Material')
    : [];
  // loading products when selectedFiltersOptions change
  const products = useProductLoader(
    selectedColors,
    SelectedMaterials,
    selectedFiltersOptions,
  );

  const toggleFilterPanelVisibility = () =>
    setFilterPanelVisibility(!filterPanelVisibility);

  const handleCheckboxChange = event => {
    const id = event.target.id;
    const checked = event.target.checked;
    const filterName = event.target.name;
    const filtersOptions = selectedFiltersOptions;

    let array = filtersOptions.get(filterName);
    if (array) {
      if (checked) {
        !array.includes(id) && array.push(id);
      } else {
        if (array.includes(id)) {
          let arr = [...array];
          arr.splice(arr.indexOf(id), 1);
          array = arr;
        }
      }
      filtersOptions.set(filterName, array);
    } else {
      filtersOptions.set(filterName, [id]);
    }

    setSelectedFiltersOptions(new Map(filtersOptions));
  };

  const clearAllFilterOptions = filterName => {
    const filtersOptions = selectedFiltersOptions;
    filtersOptions.set(filterName, []);
    setSelectedFiltersOptions(new Map(filtersOptions));
  };

  return (
    <SelectedFilterOptionsContext.Provider value={selectedFiltersOptions}>
      <Header
        filterButtonVisible={filterPanelVisibility}
        toggleFilterPanelVisibility={toggleFilterPanelVisibility}
      />
      <Layout>
        <ProductStream products={products} />
        {filterPanelVisibility && (
          <FilterPanel
            filters={filters}
            handleCheckboxChange={handleCheckboxChange}
            handleSubmit={toggleFilterPanelVisibility}
            clearAllFilterOptions={clearAllFilterOptions}
          />
        )}
      </Layout>
    </SelectedFilterOptionsContext.Provider>
  );
};

const Layout = styled.article`
  padding: 0 20px;
`;

export default ProductCatalogue;
