import React from 'react';
import { createGlobalStyle } from 'styled-components';
import ProductCatalogue from './ProductCatalogue';

const App = () => {
  return (
    <>
      <GlobalStyle />
      <ProductCatalogue />
    </>
  );
};

const GlobalStyle = createGlobalStyle`
  * {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
  }

  body {
    font-family: Arial, Helvetica, sans-serif;
  }
`;

export default App;
